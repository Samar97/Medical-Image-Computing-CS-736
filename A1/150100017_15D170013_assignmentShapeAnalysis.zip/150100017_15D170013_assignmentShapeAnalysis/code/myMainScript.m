% Main Script to run all the Main Scripts
run('ellipses2D/myMainScript1.m')
disp('Code for Part 1 completed running')
disp('The results are saved in ../results/ellipses2D')

run('hands2D/myMainScript1.m')
disp('Code for Part 1 completed running')
disp('The results are saved in ../results/hands2D')

run('bone3D/myMainScript1.m')
disp('Code for Part 1 completed running')
disp('The results are saved in ../results/bone3D')

disp('You can find the results in the results folder and the report in the report folder')